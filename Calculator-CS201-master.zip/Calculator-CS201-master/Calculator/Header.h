//Luke Underwood
//Created 10/9/19
//Header.h
//Contains library includsions and prototypes for
//CS201 calculator group project application


#ifndef HEADER_H
#define HEADER_H

#include<iostream>
#include<string>
#include<vector>
#include<sstream>
#include<cmath>

bool getInt(int& num);

bool getDouble(double& num);


void trigMenu();


#endif